<?php
$log=$_POST['login'];
$pass=$_POST['pass'];
$fd = fopen("pass.txt", 'r') or die("не удалось открыть файл");
while(!feof($fd))
{
    $str = fgets($fd);
    $str = substr($str,0,-2);
    if(strcmp($log.'#'.$pass,$str)==0){
        echo("<script>window.location = '/pagination.php';</script>");
        fclose($fd);
        exit();
    }
}
fclose($fd);
echo "<script type=\"text/javascript\">alert(\"Логин или пароль введены неверно\");</script>";
echo("<script>window.location = 'index.html';</script>");
?>
