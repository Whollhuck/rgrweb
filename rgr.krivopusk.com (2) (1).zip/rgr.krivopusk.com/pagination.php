<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/styles/main.css">
    <title>ALEXANDER</title>
</head>
<body>
    <main class="main">
        <div class="container pag-container">
            <div>
                <table>
                    <thead>
                        <tr class="bgColor">
                            <td>Username</td>
                            <td>Firstname</td>
                            <td>Lastname</td>
                            <td>Email</td>
                            <td>Address</td>
                            <td>Mobilenumber</td>
                            <td>Age</td>
                            <td>Gender</td>
                        </tr>
                    </thead>
                    <tbody id="myTable">
                        
                    </tbody>
                </table>
            </div>
            <div>
                <div">
                <button id="PreValue">Pre</button>
                </div>
  	            <div class="nav"></div>	
	            <div>
                <button id="nextValue">Next</button>
                </div>	
            </div>
        </div>
    </main>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <script src="/scripts/main.js"></script>
</body>
</html> -->

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>My site</title>
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/slider.css">
		<link href="https://fonts.googleapis.com/css?family=Quicksand:500" rel="stylesheet">
		<script src="https://code.jquery.com/jquery-3.2.1.js"></script>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<script src="log.php"></script>
	</head>
<body>
	<div class="wrapper">
		<nav>
			<div class="logo"><a href="/index.html">My site</a></div>
			<ul>
				<li><a href="#home" data-target="anchor">Home</a></li>
				<li><a href="#about_me" data-target="anchor">About me</a></li>
				<li><a href="#hobbies" data-target="anchor">Hobbies</a></li>
				<li><a href="#favorite_films" data-target="anchor">Favorite films</a></li>
				<li><a href="#Computer" data-target="anchor">My Computer</a></li>
				<li><a class="active" href="#login" data-target="anchor">Log In</a></li>
			</ul>
		</nav>
	</div>
		<header id="home">
			<div class="first_name">ALEXANDER</div>
			<div class="second_name">Krivopusk</div>
		</header>
			<section>
				<div class="container">
					<div id="about_me">
						<h1>About me</h1>
						<p>Привет! Меня зовут Саша, я обычный студент ЧНТУ, мне 20 лет и обитаю я в городе Чернигов который находится в Украине. О себе могу рассказать немного так как жизнь у меня проста как и у всех. Дом, семья, работа. Работаю в баре "Галерея" кальянщиком. Также у меня есть моя любимая девушка с которой мне хорошо.
							Люблю отдыхать со своими друзьями в нашем узком кругу, посидеть где то выпить пивка, перекусив что то и обсудив то что было у нас за долгое время которое мы не виделись.
						</p>
					</div>
				</div>
			</section>
			<section>
				<div class="container">
					<div id="hobbies">
						<h1>Hobbies</h1>
						<div class="hobbies_item">
							<img src="img/hobbies/football.png" alt="">
							<h3>Football</h3>
							<p>Я люблю футбол.
							С моими друзьями мы можем частенько играть в него получая море эмоций.</p>
						</div>
						<div  class="hobbies_item">
							<img src="img/hobbies/swimming.png" alt="">
							<h3>Swimming</h3>
							<p>С детства я занимаюсь плаванием. Всегда люблю по плавать в басейне</p>
						</div>
						<div  class="hobbies_item">
							<img src="img/hobbies/coding.png" alt="">
							<h3>Coding</h3>
							<p>В свободное время, когда оно есть конечно, я не против по сидеть и написать 
							что то интересное для себя.</p>
						</div>
					</div>
				</div>
			</section>
			<section>
				<div class="container">
					<div id="favorite_films">
						<h1>Favorite films</h1>

						<div id="slider">
							<input type="radio" name="slider" id="slide1" checked="">
							<input type="radio" name="slider" id="slide2">
							<input type="radio" name="slider" id="slide3">
							<input type="radio" name="slider" id="slide4">
							<input type="radio" name="slider" id="slide5">
							<input type="radio" name="slider" id="slide6">
							<input type="radio" name="slider" id="slide7">
							<input type="radio" name="slider" id="slide8">
							<input type="radio" name="slider" id="slide9">
							<input type="radio" name="slider" id="slide10">

							<div id="slides">
								<div id="overflow">
									<div class="inner">
										<div class="page">
											<img src="img/films/avengers.png" />
										</div>
										<div class="page">
											<img src="img/films/avengers2.png" />
										</div>
										<div class="page">
											<img src="img/films/avengers3.png" />
										</div>
										<div class="page">
											<img src="img/films/ironman1.png" />
										</div>
										<div class="page">
											<img src="img/films/ironman2.png" />
										</div>
										<div class="page">
											<img src="img/films/ironman3.png" />
										</div>
										<div class="page">
											<img src="img/films/tor3.png" />
										</div>
										<div class="page">
											<img src="img/films/it.jpg" />
										</div>
										<div class="page">
											<img src="img/films/pirates.jpg" />
										</div>
										<div class="page">
											<img src="img/films/rpo.jpg" />
										</div>
									</div> <!--inner-->
								</div> <!--overflow-->
							</div> <!--slides-->
							
							<div id="controls">
								<label for="slide1"></label>
								<label for="slide2"></label>
								<label for="slide3"></label>
								<label for="slide4"></label>
								<label for="slide5"></label>
								<label for="slide6"></label>
								<label for="slide7"></label>
								<label for="slide8"></label>
								<label for="slide9"></label>
								<label for="slide10"></label>
							</div>
							
							<div id="active">
								<label for="slide1"></label>
								<label for="slide2"></label>
								<label for="slide3"></label>
								<label for="slide4"></label>
								<label for="slide5"></label>
								<label for="slide6"></label>
								<label for="slide7"></label>
								<label for="slide8"></label>
								<label for="slide9"></label>
								<label for="slide10"></label>
							</div>
						</div>

					</div>
				</div>
			</section>
			<section>
				<div class="container">
					<div id="Computer">
						<h1>Computer</h1>
						<div>
							<img src="img/Computer.png">
						</div>
						<div>
							<table class="Computer" cellspacing="10" cellpadding="4" rules="rows">
								<tr>
									<td>Процессор</td>
									<td>Шестиядерный AMD Ryzen 1600x (3.6-4.0 ГГц)</td>
								</tr>
								<tr>
									<td>Объем оперативной памяти</td>
									<td>DDR4 - 16 Гб</td>
								</tr>
								<tr>
									<td>Графический адаптер</td>
									<td>ASUS GTX 650 Ti Boost 2 GB</td>
								</tr>
								<tr>
									<td>Материнская плата</td>
									<td>MSI Gaming Pro B350</td>
								</tr>
								<tr>
									<td>Внутрений накопитель</td>
									<td>SSD Kingston 120 GB, HDD Seagate BarraCuda 1 TB 7200 rpm</td>
								</tr>
								<tr>
									<td>Блок Питания</td>
									<td>Vinga VPS-600P/td>
								</tr>
							</table>
						</div>
					</div>
				</div>
			</section>
			<section>
				<div id="login">

					<div class="signin">
						<form method="POST" action="log.php">
							<h2>Log In</h2>
							<input type="text" placeholder="Enter Username" name="login">
							<input type="password" placeholder="Enter Password" name="pass">
							<button type="submit" class="btnsub">Log in</button>
						</form>
					</div>

				</div>
            </section>
            <section>
				<div id="login">

					<div class="signin">
						<form method="POST" action="log.php">
							<h2>Log In</h2>
							<input type="text" placeholder="Enter Username" name="login">
							<input type="password" placeholder="Enter Password" name="pass">
							<button type="submit" class="btnsub">Log in</button>
						</form>
					</div>

				</div>
			</section>
			<script type="text/javascript" src="/scripts/script.js"></script>
</body>
</html>